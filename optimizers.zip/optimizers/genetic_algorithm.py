"""
Genetic Algorithm for synonymous codon optimization.

Objectives currently supported:
    - CAI maximization
    - Global GC constraint
    - Minimum codon changes

Designed to remain compatible with the existing project API.
"""

from __future__ import annotations

import random
import time
from typing import Dict, List, Optional, Tuple

from core.cai import calculate_cai
from core.codon_usage import get_codon_table
from core.sequence import translate_dna
from core.verification import verify_translation


# ------------------------------------------------------------
# Helpers
# ------------------------------------------------------------

def split_codons(sequence: str) -> List[str]:
    """Split a DNA sequence into codons."""
    sequence = sequence.upper().strip()

    if not sequence:
        raise ValueError("DNA sequence cannot be empty.")

    if len(sequence) % 3 != 0:
        raise ValueError(
            "DNA sequence length must be divisible by 3."
        )

    return [
        sequence[i:i + 3]
        for i in range(0, len(sequence), 3)
    ]


def gc_content(sequence: str) -> float:
    """Return GC content as a fraction."""
    if not sequence:
        raise ValueError("Sequence cannot be empty.")

    return sum(
        base in {"G", "C"}
        for base in sequence.upper()
    ) / len(sequence)


def gc_penalty(
    gc: float,
    gc_min: Optional[float],
    gc_max: Optional[float],
) -> float:
    """Penalty for violating the global GC range."""

    penalty = 0.0

    if gc_min is not None and gc < gc_min:
        penalty += gc_min - gc

    if gc_max is not None and gc > gc_max:
        penalty += gc - gc_max

    return penalty


def count_changes(
    original: List[str],
    candidate: List[str],
) -> int:
    """Count changed codon positions."""

    return sum(
        a != b
        for a, b in zip(original, candidate)
    )


# ------------------------------------------------------------
# Synonymous codons
# ------------------------------------------------------------

def build_synonymous_codons(
    protein: str,
    codon_table: Dict[str, Dict[str, float]],
) -> List[List[str]]:
    """
    Get synonymous codon choices for every amino-acid position.
    """

    result = []

    for aa in protein:

        if aa not in codon_table:
            raise ValueError(
                f"Amino acid '{aa}' not found in codon table."
            )

        choices = list(
            codon_table[aa].keys()
        )

        if not choices:
            raise ValueError(
                f"No codons available for amino acid '{aa}'."
            )

        result.append(choices)

    return result


# ------------------------------------------------------------
# Fitness
# ------------------------------------------------------------

def calculate_fitness(
    codons: List[str],
    original_codons: List[str],
    organism: str,
    gc_min: Optional[float] = None,
    gc_max: Optional[float] = None,
    cai_weight: float = 1.0,
    gc_weight: float = 10.0,
    edit_weight: float = 0.0,
) -> float:
    """
    Calculate the GA fitness.

    F =
        CAI contribution
        - GC violation penalty
        - edit penalty
    """

    dna = "".join(codons)

    cai = calculate_cai(
        dna,
        organism
    )

    gc = gc_content(dna)

    gc_loss = gc_penalty(
        gc,
        gc_min,
        gc_max
    )

    changes = count_changes(
        original_codons,
        codons
    )

    edit_rate = changes / len(
        original_codons
    )

    return (
        cai_weight * cai
        - gc_weight * gc_loss
        - edit_weight * edit_rate
    )


# ------------------------------------------------------------
# Population
# ------------------------------------------------------------

def initialize_population(
    original_codons: List[str],
    synonymous: List[List[str]],
    population_size: int,
    rng: random.Random,
) -> List[List[str]]:

    population = [
        original_codons.copy()
    ]

    while len(population) < population_size:

        individual = []

        for position, choices in enumerate(synonymous):

            original = original_codons[position]

            # Preserve some original codons.
            if (
                original in choices
                and rng.random() < 0.30
            ):
                individual.append(original)

            else:
                individual.append(
                    rng.choice(choices)
                )

        population.append(individual)

    return population


# ------------------------------------------------------------
# Selection
# ------------------------------------------------------------

def tournament_selection(
    population: List[List[str]],
    fitnesses: List[float],
    rng: random.Random,
    tournament_size: int = 3,
) -> List[str]:

    size = min(
        tournament_size,
        len(population)
    )

    indices = rng.sample(
        range(len(population)),
        size
    )

    winner = max(
        indices,
        key=lambda i: fitnesses[i]
    )

    return population[winner].copy()


# ------------------------------------------------------------
# Crossover
# ------------------------------------------------------------

def crossover(
    parent1: List[str],
    parent2: List[str],
    rng: random.Random,
) -> Tuple[List[str], List[str]]:

    if len(parent1) != len(parent2):
        raise ValueError(
            "Parents must have equal length."
        )

    if len(parent1) < 2:
        return (
            parent1.copy(),
            parent2.copy()
        )

    point = rng.randint(
        1,
        len(parent1) - 1
    )

    child1 = (
        parent1[:point]
        + parent2[point:]
    )

    child2 = (
        parent2[:point]
        + parent1[point:]
    )

    return child1, child2


# ------------------------------------------------------------
# Mutation
# ------------------------------------------------------------

def mutate(
    individual: List[str],
    synonymous: List[List[str]],
    mutation_rate: float,
    rng: random.Random,
) -> List[str]:

    result = individual.copy()

    for i, choices in enumerate(synonymous):

        if rng.random() >= mutation_rate:
            continue

        alternatives = [
            codon
            for codon in choices
            if codon != result[i]
        ]

        if alternatives:
            result[i] = rng.choice(
                alternatives
            )

    return result


# ------------------------------------------------------------
# Main GA
# ------------------------------------------------------------

def optimize_ga(
    dna_sequence: str,
    organism: str = "ecoli",
    gc_min: Optional[float] = None,
    gc_max: Optional[float] = None,
    population_size: int = 100,
    generations: int = 100,
    mutation_rate: float = 0.02,
    crossover_rate: float = 0.8,
    tournament_size: int = 3,
    elitism: int = 2,
    cai_weight: float = 1.0,
    gc_weight: float = 10.0,
    edit_weight: float = 0.0,
    seed: Optional[int] = None,
) -> Dict:

    start = time.perf_counter()

    dna_sequence = dna_sequence.upper().strip()

    original_codons = split_codons(
        dna_sequence
    )

    # Existing sequence engine
    protein = translate_dna(
        dna_sequence
    )

    # Host codon table
    codon_table = get_codon_table(
        organism
    )

    synonymous = build_synonymous_codons(
        protein,
        codon_table
    )

    rng = random.Random(seed)

    # --------------------------------------------------------
    # Initial population
    # --------------------------------------------------------

    population = initialize_population(
        original_codons,
        synonymous,
        population_size,
        rng
    )

    best = original_codons.copy()
    best_fitness = float("-inf")

    # --------------------------------------------------------
    # Evolution
    # --------------------------------------------------------

    for generation in range(generations):

        fitnesses = [
            calculate_fitness(
                individual,
                original_codons,
                organism,
                gc_min=gc_min,
                gc_max=gc_max,
                cai_weight=cai_weight,
                gc_weight=gc_weight,
                edit_weight=edit_weight,
            )
            for individual in population
        ]

        # Best individual
        best_index = max(
            range(len(population)),
            key=lambda i: fitnesses[i]
        )

        if fitnesses[best_index] > best_fitness:

            best_fitness = fitnesses[
                best_index
            ]

            best = population[
                best_index
            ].copy()

        # ----------------------------------------------------
        # Elitism
        # ----------------------------------------------------

        ranked = sorted(
            range(len(population)),
            key=lambda i: fitnesses[i],
            reverse=True
        )

        new_population = [
            population[i].copy()
            for i in ranked[:elitism]
        ]

        # ----------------------------------------------------
        # Generate children
        # ----------------------------------------------------

        while len(new_population) < population_size:

            parent1 = tournament_selection(
                population,
                fitnesses,
                rng,
                tournament_size
            )

            parent2 = tournament_selection(
                population,
                fitnesses,
                rng,
                tournament_size
            )

            if rng.random() < crossover_rate:

                child1, child2 = crossover(
                    parent1,
                    parent2,
                    rng
                )

            else:

                child1 = parent1.copy()
                child2 = parent2.copy()

            child1 = mutate(
                child1,
                synonymous,
                mutation_rate,
                rng
            )

            child2 = mutate(
                child2,
                synonymous,
                mutation_rate,
                rng
            )

            new_population.append(
                child1
            )

            if len(new_population) < population_size:

                new_population.append(
                    child2
                )

        population = new_population

    # --------------------------------------------------------
    # Final sequence
    # --------------------------------------------------------

    optimized_sequence = "".join(best)

    optimized_protein = translate_dna(
        optimized_sequence
    )

    optimized_cai = calculate_cai(
        optimized_sequence,
        organism
    )

    optimized_gc = gc_content(
        optimized_sequence
    )

    changed = count_changes(
        original_codons,
        best
    )

    edit_rate = (
        changed / len(original_codons)
    )

    protein_preserved = (
        protein == optimized_protein
    )

    # Explicit existing verification
    verification_passed = verify_translation(
        dna_sequence,
        optimized_sequence
    )

    feasible_gc = True

    if gc_min is not None:
        feasible_gc &= (
            optimized_gc >= gc_min
        )

    if gc_max is not None:
        feasible_gc &= (
            optimized_gc <= gc_max
        )

    runtime = (
        time.perf_counter() - start
    )

    return {
        "original_sequence": dna_sequence,
        "optimized_sequence": optimized_sequence,
        "protein": protein,
        "optimized_protein": optimized_protein,
        "cai": optimized_cai,
        "gc": optimized_gc,
        "fitness": best_fitness,
        "changed_codons": changed,
        "edit_rate": edit_rate,
        "protein_preserved": protein_preserved,
        "verification_passed": verification_passed,
        "feasible_gc": feasible_gc,
        "generations": generations,
        "population_size": population_size,
        "runtime": runtime,
        "seed": seed,
    }


# ------------------------------------------------------------
# Compatibility alias
# ------------------------------------------------------------

def optimize_sequence_ga(
    dna_sequence: str,
    organism: str = "ecoli",
    **kwargs
) -> Dict:

    return optimize_ga(
        dna_sequence,
        organism=organism,
        **kwargs
    )